import React from 'react';

export function Layout() {
  return (
      <div>Layout</div>
  );
}
