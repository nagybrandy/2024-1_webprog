import React from 'react'

const Auth = () => {
  return (
    <div>
      <h2>Bejelentkezés</h2>
      <h3>Email</h3><br />
      <input type="text" name='email'/>
      <h3>Jelszó</h3><br />
      <input type="password" name='password' />
    </div>
  )
}

export default Auth
