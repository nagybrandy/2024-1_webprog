import Layout from "./Layout/Layout";
import { GraphiLogics } from "./graphilogics/Graphilogics";

function App() {
  return (
    <>
      <Layout>
        <h1>GraphiLogics</h1>
        <GraphiLogics />
      </Layout>
    </>
  );
}

export default App;
